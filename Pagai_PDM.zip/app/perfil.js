import React from 'react';
import { View, Text, ScrollView, StyleSheet, StatusBar } from 'react-native';
import BottomTabs from '../components/BottomTabs';

export default function PerfilScreen() {
  return (
    <View style={styles.page}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFF" />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.headerRow}>
          <View>
            <Text style={styles.title}>Perfil</Text>
            <Text style={styles.subtitle}>Suas informações estão aqui.</Text>
          </View>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>FT</Text>
          </View>
        </View>

        <View style={styles.fieldGroup}>
          <Text style={styles.fieldLabel}>Nome</Text>
          <View style={styles.fieldBox}>
            <Text style={styles.fieldText}>Fulano Teste</Text>
          </View>
        </View>

        <View style={[styles.row, styles.dateRow]}>
          <View style={styles.smallField}>
            <Text style={styles.fieldLabel}>DD</Text>
            <View style={styles.fieldBox}><Text style={styles.fieldText}>24</Text></View>
          </View>
          <View style={styles.smallField}>
            <Text style={styles.fieldLabel}>MM</Text>
            <View style={styles.fieldBox}><Text style={styles.fieldText}>04</Text></View>
          </View>
          <View style={styles.smallField}>
            <Text style={styles.fieldLabel}>AAAA</Text>
            <View style={styles.fieldBox}><Text style={styles.fieldText}>1981</Text></View>
          </View>
        </View>

        <View style={styles.fieldGroup}>
          <Text style={styles.fieldLabel}>E-mail</Text>
          <View style={styles.fieldBox}>
            <Text style={styles.fieldText}>fulano.testemail@email.com</Text>
          </View>
        </View>
      </ScrollView>
      <BottomTabs active="Perfil" />
    </View>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  content: {
    padding: 20,
    paddingBottom: 90,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#1D1D1B',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#6E6E6E',
  },
  avatar: {
    width: 62,
    height: 62,
    borderRadius: 20,
    backgroundColor: '#1F7A8C',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    color: '#FFF',
    fontWeight: '700',
    fontSize: 20,
  },
  fieldGroup: {
    marginBottom: 20,
  },
  fieldLabel: {
    fontSize: 13,
    color: '#6B6B6B',
    marginBottom: 8,
  },
  fieldBox: {
    backgroundColor: '#F7F7F7',
    borderRadius: 18,
    padding: 16,
    borderWidth: 1,
    borderColor: '#E6E6E6',
  },
  fieldText: {
    fontSize: 15,
    color: '#1E1E1E',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  dateRow: {
    gap: 10,
  },
  smallField: {
    flex: 1,
  },
});