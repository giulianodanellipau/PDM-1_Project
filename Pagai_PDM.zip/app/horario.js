import React from 'react';
import { View, Text, ScrollView, Pressable, StyleSheet, StatusBar } from 'react-native';
import BottomTabs from '../components/BottomTabs';

const menuItems = [
  'SOU 08: Maria Stella Fagá X SESI',
  'SOU 13: Romeu Tortorelli X Astolpho L. P.',
  'SOU 18: Planalto Verde X Vila Nery',
  'SOU 57: Douradinho X Estação Fepasa',
  'SOU 71: Medeiros X Villeneuve',
  'Outros',
];

export default function HorarioScreen() {
  return (
    <View style={styles.page}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFF" />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>Horários e Linhas</Text>
        <Text style={styles.subtitle}>Selecione o serviço</Text>

        <View style={styles.card}>
                  <Text style={styles.cardTitle}>SOU</Text>
                  <Text style={styles.cardDescription}>
                    Ônibus SOU: São Carlos, SP
                  </Text>
                </View>

        {menuItems.map((item, index) => (
          <View key={index} style={styles.listItem}>
            <Text style={styles.listItemText}>{item}</Text>
            <Text style={styles.listItemHelp}></Text>
          </View>
        ))}
      </ScrollView>
      <BottomTabs active="Horario" />
    </View>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  content: {
    padding: 20,
    paddingBottom: 90,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    marginBottom: 6,
    color: '#1D1D1B',
  },
  subtitle: {
    fontSize: 14,
    color: '#6E6E6E',
    marginBottom: 20,
  },
  card: {
    backgroundColor: '#F5F5F5',
    borderRadius: 22,
    padding: 18,
    marginBottom: 20,
  },
  cardLabel: {
    fontSize: 13,
    color: '#6E6E6E',
    marginBottom: 4,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1F7A8C',
  },
  listItem: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: '#E4E4E4',
    marginBottom: 14,
  },
  listItemText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1D1D1B',
    marginBottom: 6,
  },
  listItemHelp: {
    fontSize: 13,
    color: '#6B6B6B',
  },
});