﻿import React from 'react';
import { View, Text, StyleSheet, Pressable, StatusBar, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import BottomTabs from '../components/BottomTabs';

const menuItems = [
  { label: 'Recarga', subtitle: 'Selecione o serviço para recarga', route: '/recarga' },
  { label: 'Tickets', subtitle: 'Veja opções de tickets', route: '/tickets' },
  { label: 'Horário', subtitle: 'Consulte horários e direções', route: '/horario' },
  { label: 'Perfil', subtitle: 'Acesse seus dados pessoais', route: '/perfil' },
];

export default function HomeScreen() {
  const router = useRouter();

  return (
    <View style={styles.page}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFF" />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>Pagaí</Text>
        <Text style={styles.subtitle}>Selecione uma das páginas abaixo para continuar.</Text>

        {menuItems.map((item) => (
          <Pressable
            key={item.label}
            onPress={() => router.push(item.route)}
            style={({ pressed }) => [styles.card, pressed && styles.cardPressed]}
          >
            <Text style={styles.cardLabel}>{item.label}</Text>
            <Text style={styles.cardSubtitle}>{item.subtitle}</Text>
          </Pressable>
        ))}
      </ScrollView>
      <BottomTabs active="Home" />
    </View>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  content: {
    paddingTop: 40,
    paddingHorizontal: 20,
    paddingBottom: 90,
  },
  title: {
    fontSize: 30,
    fontWeight: '800',
    color: '#1F7A8C',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 15,
    color: '#5A5A5A',
    marginBottom: 22,
  },
  card: {
    backgroundColor: '#F7F7F7',
    borderRadius: 22,
    padding: 18,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#E5E5E5',
  },
  cardPressed: {
    opacity: 0.82,
  },
  cardLabel: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1F7A8C',
    marginBottom: 6,
  },
  cardSubtitle: {
    fontSize: 14,
    color: '#5A5A5A',
    lineHeight: 20,
  },
});