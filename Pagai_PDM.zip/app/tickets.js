import React from 'react';
import { View, Text, ScrollView, Pressable, StyleSheet, StatusBar } from 'react-native';
import BottomTabs from '../components/BottomTabs';

const fields = [
  { label: 'Title' },
  { label: 'Title' },
  { label: 'Title' },
  { label: 'Title' },
];

export default function TicketsScreen() {
  return (
    <View style={styles.page}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFF" />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>Tickets</Text>
        <Text style={styles.subtitle}>Selecione o serviço</Text>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>CPTM</Text>
          <Text style={styles.cardDescription}>
            Recarregue pressionando o botão ao lado, essa recarga irá ser designada a (Metrô)
          </Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>ViaQuatro</Text>
          <Text style={styles.cardDescription}>
            Recarregue pressionando o botão ao lado, essa recarga irá ser designada a (Metrô)
          </Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>ViaMobilidade</Text>
          <Text style={styles.cardDescription}>
            Recarregue pressionando o botão ao lado, essa recarga irá ser designada a (Metrô)
          </Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>MetrôSP</Text>
          <Text style={styles.cardDescription}>
            Recarregue pressionando o botão ao lado, essa recarga irá ser designada a (Metrô)
          </Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>VLT SP</Text>
          <Text style={styles.cardDescription}>
            Recarregue pressionando o botão ao lado, essa recarga irá ser designada a (VLT)
          </Text>
        </View>
        
      </ScrollView>
      <BottomTabs active="Tickets" />
    </View>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  content: {
    padding: 20,
    paddingBottom: 90,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    marginBottom: 6,
    color: '#1D1D1B',
  },
  subtitle: {
    fontSize: 14,
    color: '#6E6E6E',
    marginBottom: 20,
  },
  card: {
    backgroundColor: '#F5F5F5',
    borderRadius: 22,
    padding: 18,
    marginBottom: 20,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 10,
    color: '#1F7A8C',
  },
  cardDescription: {
    fontSize: 14,
    color: '#5A5A5A',
    lineHeight: 20,
  },
  fieldRow: {
    marginBottom: 14,
  },
  fieldLabel: {
    fontSize: 13,
    color: '#5A5A5A',
    marginBottom: 8,
  },
  fieldButton: {
    backgroundColor: '#F7F7F7',
    borderRadius: 16,
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: '#E8E8E8',
  },
  fieldButtonPressed: {
    opacity: 0.75,
  },
  fieldButtonText: {
    fontSize: 15,
    color: '#1C1C1C',
  },
});