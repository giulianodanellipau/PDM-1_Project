import React from 'react';
import { View, Text, ScrollView, Pressable, StyleSheet, StatusBar } from 'react-native';
import BottomTabs from '../components/BottomTabs';

const services = [
  { title: 'Metrô' },
  { title: 'Trem' },
  { title: 'VLT' },
  { title: 'Outros' },
];

export default function RecargaScreen() {
  return (
    <View style={styles.page}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFF" />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>Recarga</Text>
        <Text style={styles.subtitle}>Selecione o serviço</Text>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>SOU</Text>
          <Text style={styles.cardDescription}>
            Recarregue pressionando o botão ao lado, essa recarga irá ser designada a (Ônibus)
          </Text>
        </View>

        {services.map((item) => (
          <Pressable key={item.title} style={({ pressed }) => [styles.option, pressed && styles.optionPressed]}>
            <Text style={styles.optionLabel}>{item.title}</Text>
            <Text style={styles.optionArrow}>›</Text>
          </Pressable>
        ))}
      </ScrollView>
      <BottomTabs active="Recarga" />
    </View>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  content: {
    padding: 20,
    paddingBottom: 90,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    marginBottom: 6,
    color: '#1D1D1B',
  },
  subtitle: {
    fontSize: 14,
    color: '#6E6E6E',
    marginBottom: 20,
  },
  card: {
    backgroundColor: '#F5F5F5',
    borderRadius: 22,
    padding: 18,
    marginBottom: 20,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 10,
    color: '#1F7A8C',
  },
  cardDescription: {
    fontSize: 14,
    color: '#5A5A5A',
    lineHeight: 20,
  },
  option: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    paddingVertical: 18,
    paddingHorizontal: 16,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#E4E4E4',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  optionPressed: {
    opacity: 0.8,
  },
  optionLabel: {
    fontSize: 15,
    fontWeight: '600',
    color: '#1E1E1E',
  },
  optionArrow: {
    fontSize: 20,
    color: '#C4C4C4',
  },
});