import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';

const tabs = [
  { key: 'Home', label: 'Início', route: '/' },
  { key: 'Recarga', label: 'Recarga', route: '/recarga' },
  { key: 'Tickets', label: 'Tickets', route: '/tickets' },
  { key: 'Horario', label: 'Horário', route: '/horario' },
  { key: 'Perfil', label: 'Perfil', route: '/perfil' },
];

export default function BottomTabs({ active }) {
  const router = useRouter();

  return (
    <View style={styles.tabBar}>
      {tabs.map((tab) => (
        <Pressable
          key={tab.key}
          style={({ pressed }) => [
            styles.tabItem,
            active === tab.key && styles.tabItemActive,
            pressed && styles.tabPressed,
          ]}
          onPress={() => router.push(tab.route)}
        >
          <Text style={[styles.tabLabel, active === tab.key && styles.tabLabelActive]}>{tab.label}</Text>
        </Pressable>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E3E3E3',
    paddingVertical: 10,
    paddingHorizontal: 10,
  },
  tabItem: {
    flex: 1,
    marginHorizontal: 4,
    borderRadius: 16,
    paddingVertical: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabItemActive: {
    backgroundColor: '#1F7A8C',
  },
  tabLabel: {
    fontSize: 12,
    color: '#6E6E6E',
    fontWeight: '600',
  },
  tabLabelActive: {
    color: '#FFFFFF',
  },
  tabPressed: {
    opacity: 0.7,
  },
});